"""Persistent topic tracker for AI PINTAR Content Engine 2.0.
Uses topics.json and topic_state.json in this directory (or supplied paths).
"""
import json, random
from pathlib import Path
from datetime import datetime, timezone

class TopicMemory:
    def __init__(self, topics_path=None, state_path=None):
        base = Path(__file__).resolve().parent.parent
        self.topics_path = Path(topics_path or base / "topics.json")
        self.state_path = Path(state_path or base / "topic_state.json")
        self.topics = json.loads(self.topics_path.read_text(encoding="utf-8"))
        self.state = self._load_state()

    def _load_state(self):
        if self.state_path.exists():
            try: return json.loads(self.state_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError): pass
        return {"used_ids": [], "history": [], "bank_version": 1}

    def _save(self):
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.state_path)

    def choose(self, seed=None):
        used = set(self.state.get("used_ids", []))
        available = [t for t in self.topics if t["id"] not in used]
        if not available:
            return {"bank_exhausted": True, "message": "Bank topik habis; tambahkan topik baru sebelum melanjutkan.", "topic": None}
        rng = random.Random(seed)
        topic = rng.choice(available)
        self.state["used_ids"].append(topic["id"])
        self.state["history"].append({"id": topic["id"], "title": topic["title"], "used_at": datetime.now(timezone.utc).isoformat()})
        self._save()
        return {"bank_exhausted": False, "topic": topic}

    def mark_failed(self, topic_id, reason="production_failed"):
        # Explicitly release a topic only if production failure was recorded.
        self.state["used_ids"] = [x for x in self.state.get("used_ids", []) if x != topic_id]
        self.state.setdefault("failures", []).append({"id": topic_id, "reason": reason, "at": datetime.now(timezone.utc).isoformat()})
        self._save()

    def remaining(self):
        return len([t for t in self.topics if t["id"] not in set(self.state.get("used_ids", []))])

    def reset_bank(self):
        # Explicit admin action; never auto-reset after exhaustion.
        self.state["used_ids"] = []
        self.state["bank_version"] = self.state.get("bank_version", 1) + 1
        self._save()
