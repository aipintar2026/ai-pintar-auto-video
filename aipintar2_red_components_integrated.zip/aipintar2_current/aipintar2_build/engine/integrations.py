"""Provider integrations for AI PINTAR 2.0 staging. Publishing is opt-in."""
import os, json, hashlib, requests, subprocess, tempfile, math
from pathlib import Path


def pixabay_download(query, key, outdir, used_ids=None, count=5):
    used_ids=set(used_ids or [])
    params={'key':key,'q':query,'video_type':'film','per_page':20,'safesearch':'true'}
    r=requests.get('https://pixabay.com/api/videos/',params=params,timeout=30); r.raise_for_status()
    hits=r.json().get('hits',[])
    chosen=[h for h in hits if h.get('id') not in used_ids and h.get('videos',{}).get('medium',{}).get('url')][:count]
    if not chosen: raise RuntimeError('Pixabay: tidak ada footage cocok yang belum dipakai.')
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True); files=[]
    for h in chosen:
        url=h['videos'].get('medium',{}).get('url') or h['videos']['small']['url']
        p=outdir/f"pixabay_{h['id']}.mp4"
        with requests.get(url,stream=True,timeout=60) as dl:
            dl.raise_for_status()
            with p.open('wb') as f:
                for chunk in dl.iter_content(1024*1024):
                    if chunk:f.write(chunk)
        files.append(str(p))
    return files, [h['id'] for h in chosen]


def create_tts(text, output):
    """Edge TTS; voice can be changed through env. Requires edge-tts package."""
    voice=os.getenv('TTS_VOICE','id-ID-ArdiNeural')
    subprocess.run(['edge-tts','--voice',voice,'--text',text,'--write-media',str(output)],check=True,timeout=180)
    return output


def cloudinary_upload(video_path):
    cloud=os.environ['CLOUDINARY_CLOUD_NAME']; key=os.environ['CLOUDINARY_API_KEY']; secret=os.environ['CLOUDINARY_API_SECRET']
    timestamp=str(int(__import__('time').time()))
    signature=hashlib.sha1(f"timestamp={timestamp}{secret}".encode()).hexdigest()
    with open(video_path,'rb') as f:
        r=requests.post(f'https://api.cloudinary.com/v1_1/{cloud}/video/upload',data={'api_key':key,'timestamp':timestamp,'signature':signature},files={'file':f},timeout=180)
    r.raise_for_status(); data=r.json()
    if not data.get('secure_url'): raise RuntimeError('Cloudinary upload tidak mengembalikan secure_url')
    return data['secure_url']


def buffer_queue(video_url, caption, channel_ids, enabled=False):
    """Queue posts via Buffer GraphQL. Publishing requires explicit opt-in."""
    if not channel_ids:
        return {'dry_run':True,'video_url':video_url,'channels':[],'message':'tidak ada channel IDs; publikasi tidak dilakukan'}
    if not enabled or os.getenv('PUBLISH_ENABLED','false').lower()!='true':
        return {'dry_run':True,'video_url':video_url,'channels':channel_ids,'message':'publikasi disabled; tidak ada post dibuat'}
    token=os.environ['BUFFER_ACCESS_TOKEN']; endpoint='https://api.buffer.com'
    headers={'Authorization':f'Bearer {token}','Content-Type':'application/json'}
    created=[]
    for channel in channel_ids:
        payload={'query':'mutation CreatePost($input: CreatePostInput!) { createPost(input: $input) { post { id } } }','variables':{'input':{'channelId':channel,'text':caption,'assets':[{'url':video_url,'type':'video'}],'schedulingType':'automatic','mode':'addToQueue'}}}
        r=requests.post(endpoint,headers=headers,json=payload,timeout=60); r.raise_for_status(); data=r.json()
        if data.get('errors'): raise RuntimeError('Buffer GraphQL error: '+json.dumps(data['errors']))
        post=(data.get('data') or {}).get('createPost') or {}
        if not post.get('post',{}).get('id'): raise RuntimeError('Buffer tidak mengonfirmasi ID post; hentikan untuk menghindari retry ganda.')
        created.append({'channel':channel,'post_id':post['post']['id']})
    return {'dry_run':False,'created':created}
