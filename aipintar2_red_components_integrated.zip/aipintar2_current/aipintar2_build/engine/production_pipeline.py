"""Staging production workflow: script -> footage -> narration -> captions -> render -> QC -> optional cloud/publish."""
import os, json, re, subprocess, textwrap, tempfile, shutil
from pathlib import Path
from .topic_memory import TopicMemory
from .production import make_story
from .integrations import pixabay_download, create_tts, cloudinary_upload, buffer_queue
from .qc import probe_video

ROOT=Path(__file__).resolve().parent.parent

def ffmpeg_render(clips, narration, subtitles, avatar, out):
    # Normalize clips to portrait, trim/loop footage to narration length, overlay subtitles and optional presenter image.
    duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(narration)],text=True).strip())
    inputs=[]
    for clip in clips: inputs += ['-i',clip]
    inputs += ['-i',str(narration)]
    avatar_index=None
    avatar_kind=None
    if avatar and Path(avatar).exists():
        inputs+=['-i',str(avatar)]; avatar_index=len(clips)+1
        avatar_kind='video' if Path(avatar).suffix.lower() in {'.mp4','.mov','.mkv','.webm'} else 'image'
    # each clip loop and trim segments; segment length evenly allocated
    segment=max(5,duration/len(clips)); filters=[]
    for i in range(len(clips)):
        filters.append(f'[{i}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30,trim=duration={segment},setpts=PTS-STARTPTS[v{i}]')
    filters += [ ''.join(f'[v{i}]' for i in range(len(clips)))+f'concat=n={len(clips)}:v=1:a=0[bg]']
    # subtitle path escaped for ffmpeg filter
    sub=str(subtitles).replace('\\','\\\\').replace(':','\\:').replace("'","\\'")
    filters.append(f'[bg]subtitles={sub}[sub]')
    if avatar_index is not None:
        if avatar_kind == 'video':
            filters.append(f'[{avatar_index}:v]scale=360:-1,fps=30,setpts=PTS-STARTPTS[avatar];[sub][avatar]overlay=W-w-40:H-h-80:shortest=0[vout]')
        else:
            filters.append(f'[{avatar_index}:v]scale=360:-1[avatar];[sub][avatar]overlay=W-w-40:H-h-80[vout]')
        outlabel='vout'
    else: outlabel='sub'
    cmd=['ffmpeg','-y']+inputs+['-filter_complex',';'.join(filters),'-map',f'[{outlabel}]','-map',f'{len(clips)}:a','-t',str(duration),'-c:v','libx264','-preset','medium','-crf','22','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',str(out)]
    subprocess.run(cmd,check=True,timeout=300,capture_output=True)
    return out

def caption_and_srt(topic, script, duration, output):
    caption=f"{topic['title']}\n\nBelajar AI secara praktis bersama AI PINTAR. #AI #BelajarAI #AIIndonesia"
    Path(output/'caption.txt').write_text(caption,encoding='utf-8')
    # Whole-script subtitle cue for reliability; avoids false precision in word-level timings.
    srt=f"1\n00:00:00,000 --> {int(duration//60):02d}:{int(duration%60):02d},000\n{script}\n"
    Path(output/'subtitles.srt').write_text(srt,encoding='utf-8')
    return caption

def run_pipeline(outdir='output_production', publish=False, avatar=None, channel_ids=None):
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True); work=out/'media';work.mkdir(exist_ok=True)
    key=os.environ.get('PIXABAY_API_KEY');
    if not key: raise RuntimeError('PIXABAY_API_KEY belum diset')
    mem=TopicMemory(); selected=mem.choose()
    if selected.get('bank_exhausted'): return selected
    topic=selected['topic']; story=make_story(topic); script=story.narration()
    (out/'script.txt').write_text(script,encoding='utf-8')
    # topic title/angle used as queries
    clips,ids=pixabay_download(topic.get('angle') or topic['title'],key,work)
    (out/'pixabay_ids.json').write_text(json.dumps(ids),encoding='utf-8')
    audio=out/'narration.mp3';create_tts(script,audio)
    dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(audio)],text=True).strip())
    caption=caption_and_srt(topic,script,dur,out)
    vid=out/'final_video.mp4';ffmpeg_render(clips,audio,out/'subtitles.srt',avatar,vid)
    qc=probe_video(vid)
    manifest={'topic':topic,'pixabay_ids':ids,'duration':qc['duration'],'resolution':qc['resolution'],'avatar_overlay':bool(avatar and Path(avatar).exists()),'qc':qc,'publish_requested':publish,'publish_result':'not attempted'}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    if publish:
        url=cloudinary_upload(vid);manifest['cloudinary_url']=url
        manifest['publish_result']=buffer_queue(url,caption,channel_ids or [],enabled=True)
        (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest
