from engine.integrations import buffer_queue
import os

def test_buffer_dry_run(monkeypatch):
    monkeypatch.setenv('PUBLISH_ENABLED','false')
    result=buffer_queue('https://example.invalid/video','caption',['channel'],enabled=True)
    assert result['dry_run'] is True
    assert 'tidak ada post' in result['message']

def test_buffer_disabled_even_when_requested(monkeypatch):
    monkeypatch.setenv('PUBLISH_ENABLED','false')
    result=buffer_queue('url','caption',['id'],enabled=False)
    assert result['dry_run'] is True
