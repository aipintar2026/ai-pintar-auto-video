import tempfile
from pathlib import Path
from engine.production import make_story
from engine.script_engine import validate_story

def test_story_generated_for_topic():
    topic={'id':'X','title':'Cara belajar AI','angle':'latihan prompt bertahap'}
    s=make_story(topic)
    assert validate_story(s,min_chars=100,max_chars=1200)
    assert 'AI' in s.narration()
