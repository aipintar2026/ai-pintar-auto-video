# AI PINTAR 2.0 STAGING

**Development/staging package only. It does not replace or modify AI PINTAR 1.**

## Included
- 30-topic bank and persistent topic rotation (state stored in `topic_state.json`)
- Story structure generator, caption and subtitle draft
- QC metadata checks (ffprobe) and publish safety guard/manifest
- Local offline demo video renderer (synthetic visuals/audio; explicitly not production content)
- Automated tests

## Run
`python run_staging.py` creates script, caption, SRT and metadata in `output/`.
`python run_staging.py --demo-video` additionally renders a synthetic demo MP4 locally.
`pytest -q` runs the tests.

## Production boundaries
Real narration/TTS, presenter, stock footage, music, cloud hosting, Buffer integration, durable cross-run GitHub topic-state persistence, and reconciliation are not yet integrated/validated. Publishing remains disabled by default. Never set publish enable flags until reviewed and validated.

## Production integrations (staging only)
`run_production.py` connects Pixabay footage retrieval, Edge TTS, FFmpeg subtitle/render pipeline, ffprobe QC and optional avatar image overlay. Supply a fixed avatar image at `--avatar` to use the same visual identity asset; this is a static image overlay, **not** a generated talking-head presenter. The Cloudinary uploader and Buffer queue helper are included but not automatically called in workflow; publishing is intentionally guarded and workflow runs only the staging render. Provider calls require credentials and live validation.

### Required secrets
- `PIXABAY_API_KEY` for footage retrieval
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` for cloud upload (not invoked by default)
- `BUFFER_ACCESS_TOKEN` and channel IDs for Buffer API (not invoked by default)

Never add secrets to repository files. Do not use the `--publish` switch until a reviewed human-approved workflow is created. Existing production workflow remains untouched.

Presenter and Buffer staging limitations/instructions: see `docs/RED_COMPONENTS.md`.
