import argparse,json
from engine.production_pipeline import run_pipeline
p=argparse.ArgumentParser(description='AI PINTAR 2.0 staging production')
p.add_argument('--output',default='output_production');p.add_argument('--publish',action='store_true',help='Requires PUBLISH_ENABLED=true; use only after human review');p.add_argument('--avatar',default=None,help='Path to fixed avatar image asset');p.add_argument('--channel-ids',default='',help='Comma-separated Buffer channel IDs')
a=p.parse_args(); result=run_pipeline(a.output,a.publish,a.avatar,[x.strip() for x in a.channel_ids.split(',') if x.strip()]);print(json.dumps(result,ensure_ascii=False,indent=2))
