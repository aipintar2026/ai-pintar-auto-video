# Safe staging migration guide

1. Keep current production workflow and `main.py` unchanged.
2. Create a new branch (or separate repository) for this staging package.
3. Copy the staging package into the repository root only in that branch.
4. Keep the new workflow manual-only. It does not replace the production cron.
5. Configure `PIXABAY_API_KEY` as a GitHub Actions secret; do not paste keys into code.
6. Run tests first, then run the staging workflow and inspect downloaded artifact/video.
7. If avatar overlay is desired, provide a licensed/approved static presenter image. Static overlay is not lip-sync/talking-head generation.
8. Cloudinary and Buffer functions are included but not automatically called by workflow. Validate these in a separate manually approved run, with duplicate checks and channel IDs confirmed.
9. Only after multiple successful end-to-end staging tests, plan migration in a separate change with rollback instructions.

## Rollback
Production workflow is not changed by this staging package. If staged changes are copied into a test branch, discard/revert that branch without touching `main`.
