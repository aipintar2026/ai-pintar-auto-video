# Presenter & Buffer staging status

## Presenter overlay
The renderer accepts `--avatar PATH` and overlays either a PNG/JPG image or a video file (MP4/MOV/MKV/WebM) in the lower-right corner. The staging workflow will automatically use `assets/presenter.mp4` or `assets/presenter.png` if present. A video overlay can show motion, but this is not AI lip-sync; a lip-synced avatar requires a separately generated presenter clip/provider.

## Buffer publishing
Publishing is opt-in via the manual workflow input `publish=true` and the `PUBLISH_ENABLED` repository secret set to `true`. Configure `BUFFER_ACCESS_TOKEN`, `BUFFER_CHANNEL_IDS` (comma-separated), and Cloudinary secrets only in GitHub Secrets. Live account/channel permissions are not validated until run against the account. The Buffer code verifies the returned post ID and aborts if no ID is returned.

## Safe test
First run with publish=false. Inspect the video artifact. Only after manual review, configure secrets and run with publish=true. This will queue content; it is not a dry-run. Do not run twice unless checking the queue first.
